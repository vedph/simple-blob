#!/bin/bash
# /blob/cli: the CLI binaries
# /blob/up: the folder with files to upload
# /blob/dn: empty folder

BLOB=~/blob/cli/blob
UPDIR=~/blob/up
DNDIR=~/blob/dn
BLPWD=P4ss-W0rd!

echo SIMPLE BLOB DEMO
echo Please ensure that the BLOB service is running.
echo 1. upload
echo 2. list
echo 3. get-info
echo 4. delete
echo 5. download
echo 6. add-props
echo 7. list-users
echo 8. add-user
echo 9. add-user-roles
echo 10. delete-user
read -p "Press enter to continue"

echo 1. UPLOAD
echo Files from $UPDIR will be uploaded.
ls $UPDIR
read -p "Press enter to continue"
$BLOB upload $UPDIR \*.\* -u zeus -p $BLPWD -c
read -p "Press enter to continue"

echo 2. LIST
echo The first page of the files list will be shown.
read -p "Press enter to continue"
$BLOB list -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 3. GET-INFO
echo Get info about a BLOB item.
read -p "Press enter to continue"
$BLOB get-info aeneis.txt -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 4. DELETE
echo Delete a BLOB item.
read -p "Press enter to continue"
$BLOB delete chick.jpg -c -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 5. DOWNLOAD
echo Download BLOB items.
read -p "Press enter to continue"
$BLOB download $DNDIR -u zeus -p $BLPWD
read -p "Press enter to continue"
ls $DNDIR /b /o
read -p "Press enter to continue"

echo 6. ADD-PROPS
echo Add properties to a BLOB item.
read -p "Press enter to continue"
$BLOB add-props aeneis.txt -o author=Vergilius -u zeus -p $BLPWD
read -p "Press enter to continue"
$BLOB get-info aeneis.txt -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 7. LIST-USERS
echo List registered users.
read -p "Press enter to continue"
$BLOB list-users -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 8. ADD-USER
echo Add a user.
read -p "Press enter to continue"
$BLOB add-user tester $BLPWD tester@somewhere.org -f Mario -l Rossi -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 9. ADD-USER-ROLES
echo Add roles to an existing user.
read -p "Press enter to continue"
$BLOB add-user-roles tester -r admin -u zeus -p $BLPWD
read -p "Press enter to continue"
$BLOB list-users -u zeus -p $BLPWD
read -p "Press enter to continue"

echo 10. DELETE-USER
echo Delete a user.
read -p "Press enter to continue"
$BLOB delete-user tester -u zeus -p $BLPWD
read -p "Press enter to continue"
$BLOB list-users -u zeus -p $BLPWD
